# Abstract
"JSON Video" is the second example device on how to fetch web data in json format - in particular  #ableton tagged looped videos from the online video sharing service “Vine” using their [API](https://github.com/starlock/vino/wiki/API-Reference). 


# Guidelines

* Just click on “Fetch Video”. 

* The “Audio” and “Video” buttons enable or disable audio and video respectively, whilst the “Feedback” and “Frame Delay” dials allow you to apply some basic effects on the image. 
