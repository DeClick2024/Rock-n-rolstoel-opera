# Abstract
A simple but useful OSC data monitor - it displays incoming OSC messages.


# Guidelines

* Enter your Port number and any incoming data on this port will be displayed. 

* The Speed parameter lets you limit the data stream - OSC data can be a lot and fast, so use this parameter to adjust the data stream.

* The Freeze and Clear functions act only on the display, not on the data stream itself.
